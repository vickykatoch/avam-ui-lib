import { Component } from '@angular/core';
import { JettStore } from './utils';
import { ReducerHelper } from './store/reducers';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'jett-store';
  
  constructor() {
    JettStore.instance.initialize({},ReducerHelper.reducers());
    console.log(JettStore.instance.value);
  }
  
  
}
