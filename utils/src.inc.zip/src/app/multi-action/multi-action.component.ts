import { Component, OnInit } from '@angular/core';
import { JettStore } from '../utils';
import { OrderReceivedAction } from '../store/actions/order-actions';

@Component({
  selector: 'app-multi-action',
  templateUrl: './multi-action.component.html',
  styleUrls: ['./multi-action.component.scss']
})
export class MultiActionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  orderReceiveAction(orderId: string) {
    const order = {
      orderId,
      ts : Date.now(),
    };
    JettStore.instance.dispatch(new OrderReceivedAction(order));
  }
}
