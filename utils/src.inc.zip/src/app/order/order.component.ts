import { Component, OnInit } from '@angular/core';
import { JettStore } from '../utils';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  orders: any;
  subscription: any;

  constructor() {
    this.subscription = JettStore.instance.subscribe((state) => {
      this.orders = state['orders'];
    });

  }

  toggleSubscription() {
    if (this.subscription) {
      this.subscription();
      this.subscription = null;
      this.orders = Object.assign({}, this.orders);
    } else {
      this.subscription = JettStore.instance.subscribe(this.onOrderReceived.bind(this));
    }

  }
  private onOrderReceived(state: any) {
    this.orders = state['orders'];
  }
  ngOnInit() {
  }

}
