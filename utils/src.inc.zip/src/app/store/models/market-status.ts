export interface MarketStatus {
    
}