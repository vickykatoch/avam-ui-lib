export interface MarketData {
    
}