import { Action } from "../../utils";

export class OrderReceivedAction implements Action {
    type: string = 'ORDER_RECEIVED';    
    constructor(public payload: any) {
    }
}
export class OrderSubmitAction implements Action {
    type: string = 'ORDER_SUBMITTED';    
    constructor(public payload: any) {
    }
}

export type OrderActions = OrderReceivedAction | OrderSubmitAction;
