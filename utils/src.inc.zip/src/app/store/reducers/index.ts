import { OrderReducer } from "./order-reducer";

export class ReducerHelper {
    static reducers(): { [key: string]: Function } {
        return {
            'orders' : OrderReducer
        };
    }
}