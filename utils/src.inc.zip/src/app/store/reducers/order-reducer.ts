import { Action } from "../../utils";
import { OrderActions } from "../actions/order-actions";


export const OrderReducer = (state = {}, action: OrderActions): { [key: string]: any } => {
    switch(action.type) {
        case 'ORDER_RECEIVED': {
            state[action.payload.orderId] = action.payload;
            break;
        };
        case 'ORDER_SUBMITTED' : {
            break;
        }

    }
    return state;
};