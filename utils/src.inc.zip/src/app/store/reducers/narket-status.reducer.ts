import { Action } from "../../utils";

export const MarketStatusReducer = (state = {}, action: Action) => {
    switch(action.type) {
        
    }
    return state;
};