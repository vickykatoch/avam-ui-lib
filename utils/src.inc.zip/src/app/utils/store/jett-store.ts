//#region IMPORTS
import { Action } from './ex-models';
import { Subject, Subscription } from 'rxjs';
//#endregion

const DUMMY_ACTION : Action = {
    type: 'DUMMY_ACTION'
};

export class JettStore {
    //#region STATIC MEMBERS
    private static _instance = new JettStore();
    constructor() {
        if (JettStore._instance) {
            throw new Error('Error: Instantiation failed: Use JettStore.instance instead of new');
        }
        JettStore._instance = this;
    }
    static get instance(): JettStore {
        return JettStore._instance;
    }
    //#endregion

    //#region INSTANCE MEMBERS

    //#region FIELDS
    private reducersMap = new Map<string, Function>();
    private state: { [key: string]: any } = {};
    // private stateChangeNotifier = new Subject<any>();
    private subscribers = [];
    //#endregion

    //#region PUBLIC METHODS
    get value(): any {
        return this.state;
    }
    initialize(initialState = {}, reducers: { [key: string]: Function }) {
        this.state = initialState || this.state;
        Object.keys(reducers).forEach(key => {
            this.reducersMap.set(key, reducers[key]);
            this.state[key] = reducers[key](undefined,DUMMY_ACTION);
        });
    }
    dispatch(action: Action) {
        this.state = this.reduce(this.state,action);
        this.notify();
    }
    subscribe(func: Function): any {
        this.subscribers.push(func);
        this.notify();
        return () => {
            this.subscribers = this.subscribers.filter(f => f !== func);
        };
    }
    //#endregion

    //#region HELPER METHODS
    private notify() {
        this.subscribers.forEach(subscriber => {
            subscriber(this.state);
        });
    }
    private reduce(state: { [key: string]: any }, action: Action) : { [key: string]: any } {
        const newState = {};
        this.reducersMap.forEach((reducer, name) => {
            newState[name] = reducer(state[name],action);
        });
        return newState;
    }
    //#endregion

    //#endregion
}