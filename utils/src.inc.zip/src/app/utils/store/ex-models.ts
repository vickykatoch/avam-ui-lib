import { SubscriptionLike } from "rxjs";

export interface Action {
    readonly type: string;
    payload? : any;
}

