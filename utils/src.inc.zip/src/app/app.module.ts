import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WorkerComponent } from './worker/worker.component';
import { MarketStatusComponent } from './market-status/market-status.component';
import { OrderComponent } from './order/order.component';
import { MarketDataComponent } from './market-data/market-data.component';
import { MultiActionComponent } from './multi-action/multi-action.component';


@NgModule({
  declarations: [
    AppComponent,
    WorkerComponent,
    MarketStatusComponent,
    OrderComponent,
    MarketDataComponent,
    MultiActionComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
