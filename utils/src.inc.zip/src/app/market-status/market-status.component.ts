import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-status',
  templateUrl: './market-status.component.html',
  styleUrls: ['./market-status.component.scss']
})
export class MarketStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
