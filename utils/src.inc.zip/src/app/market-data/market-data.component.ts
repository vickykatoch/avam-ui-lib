import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-data',
  templateUrl: './market-data.component.html',
  styleUrls: ['./market-data.component.scss']
})
export class MarketDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
